import UIKit

var greeting = "Hello, playground"


var names = "ayca"

names.append("sudal")
names.uppercased()
names.lowercased()

names = "isil"


let birey = 100


let dikta = 25
 birey/dikta

let bilet = String(50)



let mykelime = "araba"

let mydenem2 = mykelime.uppercased()


//--------------------------parto tu--------------------------------


var  favorite = ["age of mito","kal of tuty","elden ring","dyling light"]

favorite [0]
favorite [3].uppercased()
favorite.last
favorite.append("ucak")
favorite.last
favorite.count
favorite[favorite.count - 2]
favorite.sort()



var  favorite2 = ["age of mito","kal of tuty","elden ring","dyling light",20,false] as [Any]

favorite2 [5]


var sayisal = [5,6,7,21,3,6,4]

sayisal.append(82)


